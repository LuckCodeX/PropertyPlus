﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PropertyPlus.Models
{
    public class TokenModel
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public int Role { get; set; }
    }
}