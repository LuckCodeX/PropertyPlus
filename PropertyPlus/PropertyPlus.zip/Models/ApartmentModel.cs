﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PropertyPlus.Models
{
    public class ApartmentModel
    {
        public int Id { get; set; }
    }
}