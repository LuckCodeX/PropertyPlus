﻿function ApartmentCtrl($scope,
    $rootScope,
    $stateParams,
    $location,
    $timeout,
    xhrService,
    $anchorScroll) {
    
}

app.controller('ApartmentCtrl', ApartmentCtrl);